
"""Defines URL patterns for board_games."""
from django.urls import path
from . import views
app_name = 'board_games'
urlpatterns = [
    # Home page
    path('', views.index, name='index'),
    # Page that shows all games.
    path('games/', views.games, name='games'),
    # Detail page for a single game.
    path('game/<int:game_id>/', views.game, name='game'),
    # Page for adding new game
    path('new_game/', views.new_game, name='new_game'),
    # Page for adding a new borrower.
    path('new_borrower/<int:game_id>/', views.new_borrower, name='new_borrower'),
    # Page for return game.
    path('return_game/<int:game_id>/', views.return_game, name='return_game'),
    # Page for editing a game.
    path('edit_game/<int:game_id>/', views.edit_game, name='edit_game'),
    # Page for delete a game.
    path('delete_game/<int:game_id>/', views.delete_game, name='delete_game'),
]
