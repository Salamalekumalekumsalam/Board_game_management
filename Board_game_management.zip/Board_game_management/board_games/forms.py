
from django import forms
from .models import Game, Borrower

class GameForm(forms.ModelForm):
    class Meta:
        model = Game
        fields = ['name', 'discription']
        labels = {'name': 'Game name', 'discription':'Description'}

class BorrowForm(forms.ModelForm):
    class Meta:
        model = Borrower
        fields = []
        labels = {}
        
     
