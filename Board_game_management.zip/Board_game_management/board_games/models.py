from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Game(models.Model):
    """A game in the Board Game."""
    name = models.CharField(max_length=200)
    discription = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)
    date_modified = models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    def __str__(self):
        """Return a string representation of the game model."""
        return f"{self.name}: {self.discription}"
    
class Borrower(models.Model):
    """Borrower of a game."""
    game = models.ForeignKey(Game, on_delete=models.CASCADE)  # Connect game and borrower
    name = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    class Meta:
        verbose_name_plural = 'borrowers'
    def __str__(self):
        """Return a game borrower."""
        return f"{self.owner}"
    