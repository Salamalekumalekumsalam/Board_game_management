from django.shortcuts import render, redirect

# Create your views here.

from .models import Game, Borrower
from .forms import GameForm, BorrowForm

def index(request):
    """The home page for Board Game Management."""
    return render(request, 'htmls/index.html')

def games(request):
    """Show all games."""
    games = Game.objects.order_by('date_added')
    context = {'games': games}
    return render(request, 'htmls/games.html', context)

def game(request, game_id):
    """Show a single game and all its entries."""
    game = Game.objects.get(id=game_id)
    borrowers = game.borrower_set.order_by('-date_added')
    context = {'game': game, 'borrowers': borrowers}
    return render(request, 'htmls/game.html', context)

def new_game(request):
    """Add a new game"""
    if request.method != 'POST':
        # No data submitted; create a blank form
        form = GameForm()
    else:
        # POST data submitted; process data
        form = GameForm(data=request.POST)
        if form.is_valid():
            new_game = form.save(commit=False)
            new_game.owner = request.user
            new_game.save()
            return redirect('board_games:games')
    # Display a blank or invalid form
    context = {'form': form}
    return render(request, 'htmls/new_game.html', context)

def new_borrower(request, game_id):
    """Add a borrower."""
    game = Game.objects.get(id=game_id)
    borrowers = Borrower.objects.filter(owner=request.user).order_by('date_added') 
    print(borrowers) 
    message = ""

    if borrowers.__len__() >= 3:
        form = BorrowForm()
        message = "Please return one of the old games before borrowing the 4th game."
    else:
        if request.method != 'POST':
            # No data submitted; create a blank form.
            form = BorrowForm()
        else:
            # POST data submitted; process data.
            form = BorrowForm(data=request.POST)
            if form.is_valid():
                new_borrower = form.save(commit=False)
                new_borrower.game = game
                new_borrower.owner = request.user
                new_borrower.save()
                return redirect('board_games:game', game_id=game_id)
        
    # Display a blank or invalid form.
    context = {'game': game, 'form': form, 'message': message}
    return render(request, 'htmls/new_borrower.html', context)   

def return_game(request, game_id):
    """Show a single game and all its entries."""
    game = Game.objects.get(id=game_id)
    borrowers = game.borrower_set.order_by('-date_added')
    borrowers.delete()

    context = {'game': game, 'borrowers': borrowers}
    return render(request, 'htmls/game.html', context)

def edit_game(request, game_id):
    """Edit an existing game."""
    game = Game.objects.get(id=game_id)
    if request.method != 'POST':
        # Initial request; pre-fill form with the current review.
        form = GameForm(instance=game)
    else:
        # POST data submitted; process data.
        form = GameForm(instance=game, data=request.POST)
        if form.is_valid():
            game = form.save(commit=False)
            game.owner = request.user
            game.save()
            return redirect('board_games:game', game_id=game.id)

    context = {'game': game, 'form': form}
    return render(request, 'htmls/edit_game.html', context)

def delete_game(request, game_id):
    """Delete a game."""
    game = Game.objects.get(id=game_id)
    #borrowers = game.borrower_set.order_by('-date_added')
    #if borrowers == []:
    game.delete()
    games = Game.objects.order_by('date_added')
    context = {'games': games}
    return render(request, 'htmls/games.html', context)